package com.test.automation.Driver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlPackage;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.beust.testng.TestNG;

import java.util.List;
import java.util.Map;
import java.util.Properties;


public class ExecuteEngine {

	public static void main(String args[]) {
		
		// Execute single test case
		// Execute more than one test case
		// Execute test cases by priority
		// Execute test cases by module i.e groups
		// Execute all test cases
		// Execute all test cases - but exclude some tests
		// Exclude all test cases - but exclude some groups
		
		// Define at package level
		// Define at class level
		
		
		
		
		File suiteProperties = new File("suite.properties");
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(suiteProperties));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		List<XmlClass> classes = new ArrayList<XmlClass>();
		List<XmlPackage> pack = new ArrayList<XmlPackage>();
		
		XmlSuite suite = new XmlSuite();
		suite.setName("Simple Config suite");
		suite.setParallel("tests");
		suite.setThreadCount(2);
		
		List<String> listeners = new ArrayList<String>();
		listeners.add("com.test.automation.listners.ReportingListner");
		//listeners.add("com.test.automation.listners.InvokedMethodListener");
		suite.setListeners(listeners);
		
		
		// 1.  Execute all Tests - by specify base package and excluding the required one's
		String browsers[] = properties.getProperty("test.execution.browser").split(",");
		 for(String browser: browsers) {
			
			Map<String,String> testParams = new HashMap<String,String>();
			testParams.put("browser", browser);
			
			XmlTest test = new XmlTest(suite);
			test.setName("Simple config test - " + browser);
			test.setParameters(testParams);
			
			XmlPackage xmlPackage = new XmlPackage(properties.getProperty("test.base.package"));
			List<String> packToExclude = new ArrayList<String>();
			
			String packagesToExclude[] = properties.getProperty("test.package.exclude").split(",");
			for (String pk : packagesToExclude) {
			   packToExclude.add(pk);
			}
			
			xmlPackage.setExclude(packToExclude);
			
			
			pack.add(xmlPackage);
			test.setPackages(pack);
		}
		
		
		//2. Exclude Groups ---- Not Working
		/*for(String browser: browsers) {
			
			System.out.println("browser: " + browser);
			Map<String,String> testParams = new HashMap<String,String>();
			testParams.put("browser", browser);
			
			XmlTest test = new XmlTest(suite);
			test.setName("Simple config test - " + browser);
			test.setParameters(testParams);
			
			
			for (String classname: properties.getProperty("test.base.class").split(",")) {
				System.out.println("class name: " + classname);
				XmlClass baseClass = new XmlClass(classname);
				
			
				classes.add(baseClass);
			}
			test.setClasses(classes);
			
			
			List<String> includeGroups = new ArrayList<String>();
			for (String g : properties.getProperty("test.execute.groups.include").split(",")) {
				
				includeGroups.add(g);
				//test.addIncludedGroup(g);
				
			}
			
			
			List<String> excludeGroups = new ArrayList<String>();
			for (String g : properties.getProperty("test.execute.groups.exclude").split(",")) {
				excludeGroups.add(g);
				//test.addExcludedGroup(g);
				
			}
			
			test.setIncludedGroups(includeGroups);
			test.setExcludedGroups(excludeGroups);	
		}*/
		
		
		
		
		
		//suite.setTests(xmlTests);
		
		suites.add(suite);
		
		@SuppressWarnings("deprecation")
		TestNG tng = new TestNG();
		tng.setXmlSuites(suites);
		tng.run(); 
		
		
		
		
	}
	
}
