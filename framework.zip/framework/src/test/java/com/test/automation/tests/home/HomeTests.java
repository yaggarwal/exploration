package com.test.automation.tests.home;

import org.testng.annotations.Test;

import com.test.automation.tests.BaseTest;

public class HomeTests extends BaseTest {

	@Test(description = "id:5", groups={"home"})
	public void test_home1() {
		try {
		driver.get("http://www.google.com");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Test(description = "id:6", groups={"home"})
	public void test_home2() {
		
		driver.get("http://www.nextag.com");
	}
	
	
}
