package com.test.automation.tests.search;

import org.testng.annotations.Test;

import com.test.automation.tests.BaseTest;

/**
 * Hello world!
 *
 */
public class App extends BaseTest 
{
    
	@Test(description = "id:1", groups={"search"})
	public void test_search1() {
		
		driver.get("http://www.google.com");
	}
	
	
	@Test(description = "id:2", groups={"search"})
	public void test_search2() {
		
		driver.get("http://www.nextag.com");
	}
	
}
