package com.test.automation.Driver;

public interface IExecuteStrategy {
	
	public void executeSingleTest();
	public void execute();
	
}
