package com.test.automation.tests.product;

import org.testng.annotations.Test;

import com.test.automation.tests.BaseTest;

public class ProductPageTest extends BaseTest {

	@Test(description = "id:3", groups={"product"})
	public void test_product1() {
		
		driver.get("http://www.google.com");
	}
	
	
	@Test(description = "id:4", groups={"product"})
	public void test_product2() {
		
		driver.get("http://www.nextag.com");
	}
	
}
