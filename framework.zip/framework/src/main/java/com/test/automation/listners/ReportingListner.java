package com.test.automation.listners;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.test.automation.ReportingUtils.ExtentUtil;

public class ReportingListner extends TestListenerAdapter{
	
	@Override
    public void onTestSuccess(ITestResult tr) {
		System.out.println("Calling testng ReportingListner: onTestSuccess" + tr.getStatus() + "," + tr.getName());
        ExtentUtil.fetchTest().pass("Passed");
    }
 
    @Override
    public void onTestFailure(ITestResult tr) {
    	System.out.println("Calling testng ReportingListner: onTestFailure" + tr.getStatus() + "," + tr.getName());
       ExtentUtil.fetchTest().fail("Failed");
    }
 
    @Override
    public void onTestSkipped(ITestResult tr) {
 
    }
 
    @Override
    public void onStart(ITestContext testContext) {
    	System.out.println("Calling testng ReportingListner: onStart" );
        ExtentUtil.createReporter("extentreport.html");
        System.out.println(testContext.getSuite().getXmlSuite());
    }
 
    @Override
    public void onFinish(ITestContext testContext) {
    System.out.println("Calling testng ReportingListner: onFinish" );
       ExtentUtil.saveReporter();
    }
 
    @Override
    public void onTestStart(ITestResult result) {
    	 System.out.println("Calling testng ReportingListner: onTestStart" );
         ExtentUtil.createTest(result.getMethod().getMethodName());
         String[] categories = result.getMethod().getGroups();
        for (String category:categories) {
            ExtentUtil.fetchTest().assignCategory(category);
        }
        ExtentUtil.fetchTest().info(result.getMethod().getDescription());
        ExtentUtil.fetchTest().assignCategory(result.getMethod().getXmlTest().getParameter("browser"));
    }	
	
}
