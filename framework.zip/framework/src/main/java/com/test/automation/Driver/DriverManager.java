package com.test.automation.Driver;

import org.openqa.selenium.WebDriver;

public abstract class DriverManager {
	
	protected WebDriver driver;
	public static ThreadLocal<WebDriver> tdDriver = new ThreadLocal<WebDriver>();
	protected abstract void startService();
	protected abstract void stopService();
	protected abstract void createDriver();
	
	public void quitDriver(){
		if(null!=getWebDriver()){
			getWebDriver().quit();
			driver = null;
		}
			
	}
	
	public WebDriver getDriver(){
		if(null==driver){
			startService();
			createDriver();
			setDriver();
		}
		
		return getWebDriver();
	}
	
	public void  setDriver() {
		tdDriver.set(driver);
	}
	
	public WebDriver getWebDriver() {
		return tdDriver.get();
	}
}