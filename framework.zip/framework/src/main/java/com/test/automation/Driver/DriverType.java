package com.test.automation.Driver;

public enum DriverType {
    CHROME,
    FIREFOX,
    IE,
    SAFARI;
}
