package com.test.automation.Driver;

import java.io.File;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

public class ChromeDriverManager extends DriverManager{

	private ChromeDriverService chService;
	
	@Override
	public void startService(){
//		if(null==chService){
//			try{
//				chService = new ChromeDriverService.Builder()
//						 .usingDriverExecutable(new File("/Users/yaggarwal/Desktop/chromedriver"))
//						 .usingAnyFreePort()
//						 .build();
//				chService.start();
//			}catch(Exception e){
//				e.printStackTrace();
//			}
//		}
	}

	@Override
	public void stopService() {
//		if(null!=chService && chService.isRunning())
//			chService.stop();
	}

	@Override
	public void createDriver() {
		System.setProperty("webdriver.chrome.driver", "chromedriver");
		//DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		//ChromeOptions options = new ChromeOptions();
		//options.addArguments("test-type");	    
		//capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		try{
		 driver = new ChromeDriver();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}