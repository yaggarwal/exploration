package com.test.automation.ReportingUtils;

import java.util.Properties;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.kstream.KeyValueMapper;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;

/*
 * Reference https://github.com/confluentinc/examples/blob/kafka-0.10.0.0-cp-3.0.0/kafka-streams/src/main/java/io/confluent/examples/streams/PageViewRegionExample.java
 * 
 */
public class KafkaStreamTest {
	
	
	public static void main(String args[]) {
		
		
		Properties streamsConfiguration = new Properties();
	    // Give the Streams application a unique name.  The name must be unique in the Kafka cluster
	    // against which the application is run.
	    streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, "pageview-region-example");
	    // Where to find Kafka broker(s).
	    streamsConfiguration.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
	    // Where to find the corresponding ZooKeeper ensemble.
	    streamsConfiguration.put(StreamsConfig.ZOOKEEPER_CONNECT_CONFIG, "localhost:2181");
	    // Where to find the Confluent schema registry instance(s)
	    streamsConfiguration.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, "http://localhost:8081");
	    // Specify default (de)serializers for record keys and for record values.
	    streamsConfiguration.put(StreamsConfig.KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
	    streamsConfiguration.put(StreamsConfig.VALUE_SERDE_CLASS_CONFIG, GenericAvroSerde.class);
	    streamsConfiguration.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

	    final Serde<String> stringSerde = Serdes.String();
	    final Serde<Long> longSerde = Serdes.Long();

	    KStreamBuilder builder = new KStreamBuilder();

	    // Create a stream of page view events from the PageViews topic, where the key of
	    // a record is assumed to be the user id (String) and the value an Avro GenericRecord
	    // that represents the full details of the page view event.  See `pageview.avsc` under
	    // `src/main/avro/` for the corresponding Avro schema.
	    KStream<String, GenericRecord> views = builder.stream("page_visits");
	    
	    KStream<String, GenericRecord> viewsByUser = views.map(new KeyValueMapper<String, GenericRecord, KeyValue<String, GenericRecord>>() {
	        @Override
	        public KeyValue<String, GenericRecord> apply(String dummy, GenericRecord record) {
	          System.out.println("site: " + record.get("site"));
	          return new KeyValue<>(record.get("site").toString(), record);
	        }
	      });
	    
	    
	    KafkaStreams streams = new KafkaStreams(builder, streamsConfiguration);
	    streams.start();

	    // Add shutdown hook to respond to SIGTERM and gracefully close Kafka Streams
	    Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
	      @Override
	      public void run() {
	        streams.close();
	      }
	    }));
	  }
	

}
