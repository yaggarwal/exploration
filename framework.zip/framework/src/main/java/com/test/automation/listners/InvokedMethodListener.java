package com.test.automation.listners;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

import com.test.automation.ReportingUtils.ExtentUtil;

public class InvokedMethodListener implements IInvokedMethodListener{

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		System.out.println("In InvokedMethodListener beforeInvocation : " + testResult.getMethod().getMethodName());
		//System.out.println(testResult.getParameters()[0]);
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		System.out.println("In InvokedMethodListener afterInvocation :" + testResult.getMethod().getMethodName());
		//System.out.println(testResult.getParameters()[0]);
	}

	
	
}
