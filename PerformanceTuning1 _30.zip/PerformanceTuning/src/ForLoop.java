
public class ForLoop {
	public static void main(String[] args) {
		for(int i=0;i<100000000;)
		{
			String str="kjhgkg"+"khjgjkg"+i;
		}
	}
}
