
package com.spring.rest.rest_client;
public class CallClientVersion {

}
