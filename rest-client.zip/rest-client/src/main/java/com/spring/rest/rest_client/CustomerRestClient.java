package com.spring.rest.rest_client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class CustomerRestClient {

	public static void main(String args[]) {
		
		RestTemplate template = new RestTemplate();
		
		//set the custom error handler which will be invoked if error occurrs
		template.setErrorHandler(new CustomExceptionHandler(template));
		
//	//Method 1 - reading as string
//		String respone = template.getForObject("http://localhost:8080/spring-rest/customer/111", String.class);
//		System.out.println(respone);
//		
//	// method 2  - converted to CustomerClientVersion object
//		CustomerClientVersion customer = template.getForObject("http://localhost:8080/spring-rest/customer/111", CustomerClientVersion.class);
//		System.out.println(customer.getCustomerId());
//		
//		//as xml
//		customer = template.getForObject("http://localhost:8080/spring-rest/customer/111?mediaType=xml", CustomerClientVersion.class);
//		System.out.println(customer.getCustomerId());
//		
//		
//		//as json
//		customer = template.getForObject("http://localhost:8080/spring-rest/customer/111?mediaType=json", CustomerClientVersion.class);
//		System.out.println(customer.getCustomerId());
		
		
	//Method 3- by specifying the response type in the headers
		HttpHeaders httpHeader = new HttpHeaders();

		List<MediaType> acceptableMediaTypes = new ArrayList<MediaType>();
		acceptableMediaTypes.add(MediaType.APPLICATION_XML);
		httpHeader.setAccept(acceptableMediaTypes);
		
		HttpEntity requestEntity = new HttpEntity(httpHeader);
		
		HttpEntity response = template.exchange("http://localhost:8080/spring-rest/customer/111",
				HttpMethod.GET, requestEntity, String.class);

		System.out.println(response.getBody());

		//handling errors on the client side
		// and how to parse/convert the returned representation
		try {
		CustomerClientVersion customer1 = template.getForObject("http://localhost:8080/spring-rest/customer/100", CustomerClientVersion.class);		
		System.out.println("Customer: " +customer1.getCustomerId());
		} catch (ResourceNotFoundException e) {
			System.out.println("mesage returned back was: " + e.getErrorObject().getMessage());
		}
		
	}
	
}
