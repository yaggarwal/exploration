package com.learn.DS

/**
 * @author yaggarwal

It is not efficient.

It is only taught broadly because it is so remarkably simple to describe and code.

 */
object BubbleSort {
  
}