package com.learn.DS

/**
 * @author yaggarwal
 */
object StackImpl extends App{
  
  val objStack = new NonEmptyStack[Int](5, new NonEmptyStack[Int](2, EmptyStack));
  print(objStack.top)
  print(objStack.pop)
  
  val objStack1 = objStack.push(6)
  print(objStack1.top)
  print(objStack1.pop.pop.pop.pop)
}

abstract class Stack[+a] {
  def push[b >: a](x: b): Stack[b] = new NonEmptyStack(x, this)
  def isEmpty: Boolean
  def top: a
  def pop: Stack[a]
}

object EmptyStack extends Stack[Nothing] {
  def isEmpty = true
  def top = throw new Error("EmptyStack.top")
  def pop = throw new Error("EmptyStack.pop")
}

class NonEmptyStack[+a](elem: a, rest: Stack[a]) extends Stack[a] {
  def isEmpty = false
  def top = elem
  def pop = rest
}
