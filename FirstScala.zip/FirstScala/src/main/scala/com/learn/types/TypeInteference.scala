package com.learn.types

/**
 * @author yaggarwal
 */
object TypeInteference {
  
  /**
   * 
   * That’s type inference in action. You can skip keying in the type details for the most part, 
   * but Scala requires type declaration in a few places. We have to specify types when:
    • defining class fields with no initial value
    • defining parameters for functions/methods
    • defining return type for a function/method, but only if we use an explicit return or use recursion
    • defining a variable with a different type than the value may imply, for example, val frequency: Double = 1
   * 
   * 
   */
}