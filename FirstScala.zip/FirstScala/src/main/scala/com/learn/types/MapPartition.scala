package com.learn.types

import com.learn.spark.SparkUtils

/**
 * @author yaggarwal
 */
object MapPartition extends App{
  
  val list = List(1,2,3,4,5,6,7,8,9,10)
  
  val sc = SparkUtils.getSparkContext("MapPartition")
  
  val pLsit = sc.parallelize(list, 3)
  
  //list.map { double(_) }
  
  //pLsit.map { double(_) }
  
  val t = pLsit.mapPartitions(fun)
  t.foreach { print }
  
  def double(a:Int) = {
  
    printf("Print one for one line: ")
    print(a)
    print("\n")
  
  }
  
 def fun(itr:Iterator[Int]) = {
   
   print("wowo..\n")
   var listItr = List[Int]()
   while(itr.hasNext) {
     listItr = listItr ::: List(itr.next())
   }
   
   listItr.iterator
   
   
 }
  
}

