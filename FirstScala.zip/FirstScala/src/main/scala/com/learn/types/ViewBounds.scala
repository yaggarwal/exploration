package com.learn.types




/**
 * @author yaggarwal
 */
object ViewBounds extends App{
  
  
  implicit def strToInt(x: String) = x.toInt
  
  print((new Container[String]).addIt("123"))
  
  print((new Container[Int]).addIt("123"))
  
  //print((new Container[Float]).addIt("123")) // This is error
  
}



//This says that A has to be “viewable” as Int. Let’s try it.
class Container[A <% Int] { 
  
  
  
  def addIt(x: A) = 123 + x
  
}

