package com.learn.types

import scala.util.Sorting

/**
 * @author yaggarwal
 */
object Sorting1 extends App{
  
  
  //using Method 1
  
  val ty = new Person("Tyler")
  val al = new Person("Al") 
  val paul = new Person("Paul")
  
  val dudes = List(ty, al, paul)
  
  val sorteddudues = dudes.sorted
  dudes.foreach { println }
  sorteddudues.foreach { println }
  
  //or you can also use in following way
  
  if (ty > al) println("true") else println("false")
  
  
  //Using Method 2
  val people = Array(Person1("bob", 30), Person1("ann", 32), Person1("carl", 19))
  Sorting.quickSort(people)(AgeOrdering)
  
  people.foreach { println }
  
  Sorting.quickSort(people)(NameOrdering)
  
  people.foreach { println }
  
}


// Method 1 - extend Ordered Trait
class Person (val name:String) extends Ordered [Person] {
  
  
  override def toString = name

  // return 0 if the same; negative if this < that; positive if this > that
  def compare (that: Person) = {
        if (this.name == that.name)
            0
        else if (this.name > that.name)
            1
        else
           -1
    }
  
} 




//Method 2
case class Person1(name:String, age:Int)
// sort by age -  you can define another ordering which sorts by name
object AgeOrdering extends Ordering[Person1] {
  def compare(a:Person1, b:Person1) = a.age compare b.age
}

object NameOrdering extends Ordering[Person1] {
  def compare(a:Person1, b:Person1) = a.name compare b.name
}