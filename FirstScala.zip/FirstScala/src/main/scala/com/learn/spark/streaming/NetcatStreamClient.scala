package com.learn.spark.streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.StreamingContext
import org.slf4j.LoggerFactory

/**
 * @author yaggarwal
 */
object NetcatStreamClient extends App{
  
    val hostName =args(0)
    val port = args(1).toInt
    val microBatchTime = args(2).toInt
    
    //Create Spark Configuration
    val sparkConf = new SparkConf().setMaster("local[2]").setAppName("NetworkWordCount")
    
    //Create SparkStreamingContext with microBatchTime which specifies how long spark should collect data
    val sparkStreamingContext = new StreamingContext(sparkConf,Seconds(microBatchTime))
    
    //Start listening for data on given host and port
    val lines = sparkStreamingContext.socketTextStream(hostName,port)
    
    // Logic for implementing word count on the input batch
    lines.flatMap(_.split(" ")).map(word => (word,1)).reduceByKey(_+_).print()
    
    //Start the stream so that data starts flowing, you must define transformation logic before calling start()
    sparkStreamingContext.start()
    sparkStreamingContext.awaitTermination()
    //logger.debug("Exiting NetcatStreamClient.main")
  
}