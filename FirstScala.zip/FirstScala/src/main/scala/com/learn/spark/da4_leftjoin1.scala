package com.learn.spark

import scala.collection.mutable.ListBuffer

/**
 * @author yaggarwal
 */
object da4_leftjoin1 extends App{
  
   val sc = SparkUtils.getSparkContext("Implementing left outer join using union")
   
   //users RDD
   // res33: Array[String] = Array(u1 UT, u2 GA, u3 CA, u4 CA, u5 GA)
   val usersRDD = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch4_users.txt")
   usersRDD.foreach { println }
   
   //transactions RDD
   // res34: Array[String] = Array("t1 p3 u1 1 300 ", "t2 p1 u2 1 100 ", "t3 p1 u1 1 100 ", "t4 p2 u2 1 10 ", "t5 p4 u4 1 9 ", "t6 p1 u1 1 100 ", "t7 p4 u1 1 9 ", t8 p4 u5 2 40)
   val transatcionRDD = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch4_transactions.txt")
   transatcionRDD.foreach { println }
   
   //get a tuples of (user_id, ('L', location))
   // res35: Array[(String, (String, String))] = Array((u1,(L,UT)), (u2,(L,GA)), (u3,(L,CA)), (u4,(L,CA)), (u5,(L,GA)))
   val userTuples = usersRDD.map { x => x.split(" ") }.map { x => (x(0), ("L", x(1))) }
   userTuples.foreach(println)
   
   //get a tuples of (user_id, ('P', product))
   // res36: Array[(String, (String, String))] = Array((u1,(P,p3)), (u2,(P,p1)), (u1,(P,p1)), (u2,(P,p2)), (u4,(P,p4)), (u1,(P,p1)), (u1,(P,p4)), (u5,(P,p4)))
    val txTuples = transatcionRDD.map { x => x.split(" ") }.map { x => (x(2), ("P", x(1))) }
   txTuples.foreach(println)
    
    //Now take the union of both the RDD
   // res38: Array[(String, (String, String))] = Array((u1,(P,p3)), (u2,(P,p1)), (u1,(P,p1)), (u2,(P,p2)), (u4,(P,p4)), (u1,(P,p1)), (u1,(P,p4)), (u5,(P,p4)), (u1,(L,UT)), (u2,(L,GA)), (u3,(L,CA)), (u4,(L,CA)), (u5,(L,GA)))
   val unionTxAndLocation =  txTuples.union(userTuples)
   unionTxAndLocation.foreach(println)
   
   
   //now group the data by key
   // res39: Array[(String, Iterable[(String, String)])] = Array((u5,CompactBuffer((P,p4), (L,GA))), (u1,CompactBuffer((P,p3), (P,p1), (P,p1), (P,p4), (L,UT))), (u2,CompactBuffer((P,p1), (P,p2), (L,GA))), (u3,CompactBuffer((L,CA))), (u4,CompactBuffer((P,p4), (L,CA))))
   val groupbyUsers = unionTxAndLocation.groupByKey();
   groupbyUsers.foreach(println)
   
   //now fetch only the values -drop the user id
   // convert the iteratable string to list and then reverse it to bring location tuple in the begining
   // res40: Array[List[(String, String)]] = Array(List((L,GA), (P,p4)), List((L,UT), (P,p4), (P,p1), (P,p1), (P,p3)), List((L,GA), (P,p2), (P,p1)), List((L,CA)), List((L,CA), (P,p4)))
   val onlyProductList = groupbyUsers.values.map(_.toList.reverse)
   
   // now here we form the tuples of the form (product, location)
   // res41: Array[List[(String, String)]] = Array(List((p4,GA)), List((p4,UT), (p1,UT), (p1,UT), (p3,UT)), List((p2,GA), (p1,GA)), List(), List((p4,CA)))
   val productLocations = onlyProductList.map(calculateProductLocations(_))
   
   // Now we should aggregate the location data by using product.
   // For aggregating by key we first use the flatmap method to actually flat the indiviual values from all the list within 
   // the RDD
   // res42: Array[(String, String)] = Array((p4,GA), (p4,UT), (p1,UT), (p1,UT), (p3,UT), (p2,GA), (p1,GA), (p4,CA))
   val allProductLocations = productLocations.flatMap { x => x.map(y => y) }
   
   // now aggreagte by key as product - 
   // this will give all the products sold in different locations
   // res43: Array[(String, Iterable[String])] = Array((p4,CompactBuffer(GA, UT, CA)), (p1,CompactBuffer(UT, UT, GA)), (p2,CompactBuffer(GA)), (p3,CompactBuffer(UT)))
   val aggregateByProduct = allProductLocations.groupByKey()
   
   // now above output may have duplicate locations. 
   // we should find unique locations for each product
   // Convert the above Itertatble[String] values to a set. Set will contain the unique values
   // res44: Array[(String, scala.collection.immutable.Set[String])] = Array((p4,Set(GA, UT, CA)), (p1,Set(UT, GA)), (p2,Set(GA)), (p3,Set(UT)))
   val productLocationUniquePair = aggregateByProduct.mapValues { x => x.toSet }
   
   //method to calculate Product and it's location
   /**
    * There are a couple of different rules and inferences going on here: first of all,
    *  Scala infers the braces when a parameter is a function, 
    *  e.g. in list.map(_ * 2) the braces are inferred, 
    *  it's just a shorter form of list.map({_ * 2}). 
    *  
    *  Secondly, Scala allows you to skip the parentheses on the last parameter list, 
    *  if that parameter list has one parameter and it is a function, 
    *  so list.foldLeft(0)(_ + _) can be written as list.foldLeft(0) { _ + _ } (or list.foldLeft(0)({_ + _}) 
    *  if you want to be extra explicit).

    However, if you add case you get, as others have mentioned, 
    a partial function instead of a function, 
    and Scala will not infer the braces for partial functions, so list.map(case x => x * 2) won't work, 
    but both list.map({case x => 2 * 2}) and list.map { case x => x * 2 } will.
    * 
    */
   def calculateProductLocations(a:List[(String, String)]) : List[(String, String)] = {
     
     var location:String = "undefined";
     var newList:ListBuffer[(String, String)] = ListBuffer()
     
     //Read above description why curly braces are used inside the map function when using case as pattern matching
     a.map( { case(a, b) =>
         println(a + " -- " + b)
         if (a == "L") {
           location = b
         } else {
           newList += ((b, location))
         }
         
     }
     )
    
     newList.toList
   }
   
   
   
}