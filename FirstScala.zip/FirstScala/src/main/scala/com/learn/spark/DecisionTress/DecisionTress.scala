package com.learn.spark.DecisionTress

import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.regression._
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.mllib.evaluation._
import org.apache.spark.mllib.tree._
import org.apache.spark.mllib.tree.model._
import org.apache.spark.rdd.RDD

/**
 * @author yaggarwal
 */
object DecisionTress {
  
  
  def main(args:Array[String]) {
    
    
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Decision tree Classifier")
    val sc = new SparkContext(conf)
    
    val rawData = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/analytics/spark/data-sets/covtype.data")
    val data = rawData.map { line =>
      val values = line.split(',').map(_.toDouble) 
      val featureVector = Vectors.dense(values.init) 
      val label = values.last - 1 
      LabeledPoint(label, featureVector)
    }
    
    //data.foreach { println }
    
//  val Array(trainData, cvData, testData) = data.randomSplit(Array(0.8, 0.1, 0.1))
//    trainData.cache()
//    cvData.cache()
//    testData.cache()
    
    def getMetrics(model: DecisionTreeModel, data: RDD[LabeledPoint]): MulticlassMetrics = {
        val predictionsAndLabels = data.map(example => (model.predict(example.features), example.label))
        new MulticlassMetrics(predictionsAndLabels) 
    }
    
   /* 
    val model = DecisionTree.trainClassifier( trainData, 7, Map[Int,Int](), "gini", 4, 100)
    val metrics = getMetrics(model, cvData)
    
    println(metrics.confusionMatrix)
    
    println(metrics.precision)*/
    
    
    /*val eavaluations = 
            for (impurity <- Array("gini", "entropy"); depth <- Array(1,2); bins <- Array(10, 11))
              yield {
                    val model = DecisionTree.trainClassifier(trainData, 7, Map[Int,Int](), impurity, depth, bins)
                    val predictionsAndLabels = cvData.map(example => (model.predict(example.features), example.label))
                    val accuracy = new MulticlassMetrics(predictionsAndLabels).precision 
                    ((impurity, depth, bins), accuracy)
              }
              
    eavaluations.sortBy(_._2).reverse.foreach(println)*/
    
//    val model = DecisionTree.trainClassifier( trainData.union(cvData), 7, Map[Int,Int](), "entropy", 20, 300)
//    val metrics = getMetrics(model, testData)
//    println(metrics.precision)
  
  
  
      val data1 = rawData.map { line =>
        val values = line.split(',').map(_.toDouble)
        val wilderness = values.slice(10, 14).indexOf(1.0).toDouble 
        val soil = values.slice(14, 54).indexOf(1.0).toDouble
        val featureVector = Vectors.dense(values.slice(0, 10) :+ wilderness :+ soil) 
        val label = values.last - 1
        //println(featureVector)
        //  println(label)
        LabeledPoint(label, featureVector)
      }
      
      val Array(trainData, cvData, testData) = data1.randomSplit(Array(0.8, 0.1, 0.1))
      trainData.cache()
      cvData.cache()
      testData.cache()
      
      val evaluations =
        for (impurity <- Array("gini", "entropy"); depth <- Array(1,2); bins <- Array(40, 41)) 
          yield {
              val model = DecisionTree.trainClassifier( trainData, 7, Map(10 -> 4, 11 -> 40), impurity, depth, bins)
              val trainAccuracy = getMetrics(model, trainData).precision 
              val cvAccuracy = getMetrics(model, cvData).precision 
              ((impurity, depth, bins), (trainAccuracy, cvAccuracy))
        }
       evaluations.sortBy(_._2).reverse.foreach(println)
    
  }
  
  
}