package com.learn.spark

import org.apache.spark.SparkContext._

/**
 * @author yaggarwal

For taking TopN in using nonunique key's and using Spark's take Ordered function
 */
object da3_nonunique extends App{
  
  
  case class UrlHits(url:String, hits:Int)
  
  //define an ordering for the above case class
  object CompareByHits extends Ordering[(String, UrlHits)] {
    
    def compare(a:(String, UrlHits), b:(String, UrlHits)) = {
      
       -1 * (a._2.hits compare b._2.hits)
    }
        
    
  }
  
   val sc = SparkUtils.getSparkContext("Finding Top N from Non Unique Key's")
   
   // variable to find the nuumber of top 10
   //val n = args(0)
   //val bN = sc.broadcast(n.toInt);
  
  val urlhitsInfo = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch3_nonunique.txt", 2)
  
  //val urlHitsRecords = urlhitsInfo.map { x => x.split(" ") }
  
  val urlHitsObjectsByParition = urlhitsInfo.mapPartitions(constructObjects(_))

  urlHitsObjectsByParition.foreach { print }
  
//  val allObjectsSplitBySpace = urlhitsInfo.map { x => x.split(" ") }
//  
//  val allObejcts = allObjectsSplitBySpace.map { x => (x(0), x(1).toInt) }
//  
//  allObejcts.foreach { print }
//  
//  val aggregateObjectsByUrl = allObejcts.reduceByKey(_ + _)
//  
//  aggregateObjectsByUrl.foreach { print }
  
  val totalHitsByURL = urlHitsObjectsByParition.reduceByKey(countSum(_, _))
  
  totalHitsByURL.foreach(print)
  
  val topN = totalHitsByURL.takeOrdered(4)(CompareByHits)
  
  topN.foreach(print)
  
  def countSum(a:UrlHits, b:UrlHits) = {
   
    //return object of type UrlHits
    UrlHits(a.url, a.hits + b.hits)
    
  }
  
  def constructObjects(itr:Iterator[String]) = {
    
    var urlObjects = List[(String,UrlHits)]()
    
    while (itr.hasNext) {
      val curRecord = itr.next();
      val splitRecord = curRecord.split(" ")
        urlObjects = (splitRecord(0), UrlHits(splitRecord(0), splitRecord(1).toInt)) :: urlObjects // Prefix object to the list   
    }
    urlObjects.iterator
  }
  
  
  
}