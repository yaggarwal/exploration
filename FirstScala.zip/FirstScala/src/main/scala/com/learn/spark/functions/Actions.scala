package com.learn.spark.functions

import com.learn.spark.SparkUtils

/**
 * @author yaggarwal
 */
object Actions extends App{
  
    
     val sc = SparkUtils.getSparkContext("Spark Secondary Sorting in memory")
   
   
    // ################### SPARK ACTIONS ########################
   
   /*
    * 1.  reduce
    * 2.  fold
    *     Both reduce and fold have same return type
    */
   
     val a = sc.parallelize(1 to 100, 3) 
     a.reduce(_ + _) 
     
     
     val b = sc.parallelize(List(1,2,3), 3) 
     b.fold(0)(_ + _)
     
      b.fold(5)(_ + _)
      /**
       * working of fold
       * 1, 2 ,3 here goes to 1 parition each
       * 
       * initial value 5 will be added in each parition result
       * 5+1 = 6
       * 5+2 = 7
       * 5+3 = 8
       * 
       * all partitions results will be collected and added, also with the initial value
       * i.e 5+ 6+7+8 = 26
       */
   
     
   /*
    * aggregate function
    */
  
  // Example 1
  val z = sc.parallelize(List(1,2,3,4,5,6), 2)
  z.mapPartitionsWithIndex(myfunc).foreach{println}
  z.aggregate(0)(math.max(_,_), _ + _)
  //res40: Int = 9
  
  
  
  //Example 2
  z.aggregate(5)(math.max(_, _), _ + _)   // result will be 16
  // reduce of partition 0 will be max(5, 1, 2, 3) = 5
  // reduce of partition 1 will be max(5, 4, 5, 6) = 6
  // final reduce across partitions will be 5 + 5 + 6 = 16 // note the final reduce include the initial value
   
   //lets first print out the contents of the RDD with partition labels 
   def myfunc(index: Int, iter: Iterator[(Int)]) : Iterator[String] = {
    iter.toList.map(x => "[partID:" + index + ", val: " + x + "]").iterator 
   }
  
  
  
  
  //Example 3
    val z1 = sc.parallelize(List("a","b","c","d","e","f"),2)
  
    //lets first print out the contents of the RDD with partition labels
    def myfunc1(index: Int, iter: Iterator[(String)]) : Iterator[String] = {
      iter.toList.map(x => "[partID:" +  index + ", val: " + x + "]").iterator
    }
    
    z1.mapPartitionsWithIndex(myfunc1).collect
    //res31: Array[String] = Array([partID:0, val: a], [partID:0, val: b], [partID:0, val: c], [partID:1, val: d], [partID:1, val: e], [partID:1, val: f])
    
    z1.aggregate("")(_ + _, _+_)
    //res115: String = abcdef
    
    // See here how the initial value "x" is applied three times.
    //  - once for each partition
    //  - once when combining all the partitions in the second reduce function.
    z1.aggregate("x")(_ + _, _+_)
    //res116: String = xxdefxabc
    

 //Example 4
    // Below are some more advanced examples. Some are quite tricky to work out.
    // The main issue with the code above is that the result of the inner min is a string of length 1. 
    // The zero in the output is due to the empty string being the last string in the list.
    // We see this result because we are not recursively reducing any further within the partition for the final string.

    val z2 = sc.parallelize(List("12","23","345","4567"),2)
    z2.aggregate("")((x,y) => math.max(x.length, y.length).toString, (x,y) => x + y)
    //res141: String = 42
    
    z2.aggregate("")((x,y) => math.min(x.length, y.length).toString, (x,y) => x + y)
    //res142: String = 11
    
    val z3 = sc.parallelize(List("12","23","345",""),2)
    z3.aggregate("")((x,y) => math.min(x.length, y.length).toString, (x,y) => x + y)
    //res143: String = 10
    
    
    /**
     * countByValue : Returns a map that contains all unique values of the RDD and their respective occurrence counts.
     *  (Warning: This operation will finally aggregate the information in a single reducer.)
     */
    val b1 = sc.parallelize(List(1,2,3,4,5,6,7,8,2,4,2,1,1,1,1,1))
    b1.countByValue
    //res27: scala.collection.Map[Int,Long] = Map(5 -> 1, 8 -> 1, 3 -> 1, 6 -> 1, 1 -> 6, 2 -> 3, 4 -> 2, 7 -> 1)
  
}