package com.learn.spark.streaming

import java.util.regex.Pattern
import java.util.regex.Matcher

/**
 * @author yaggarwal
 */
class ScalaLogAnalyzer extends Serializable {
  
        /**
          * Transform the Apache log files and convert them into a
          Map of Key/Value pair
          */
  
      def transformLogData(logLine : String) : Map[String, String] = {
        
        //Pattern which will extract the relevant data from Apache Access Log Files
        val LOG_ENTRY_PATTERN = """^(\S+) (\S+) (\S+) \[([\w:/]+\s[+\-]\d{4})\] "(\S+) (\S+) (\S+)" (\d{3}) (\S+)""";;
        val PATTERN = Pattern.compile(LOG_ENTRY_PATTERN);
        val matcher = PATTERN.matcher(logLine);
        
        if (!matcher.find()) {
             System.out.println("Cannot parse logline" + logLine);
        }
           //Finally create a Key/Value pair of extracted data and return to calling program
        createDataMap(matcher);
        
      }
      
      
      /**
          * Create a Map of the data which is extracted by
          applying Regular expression.
          */
         def createDataMap(m:Matcher):Map[String,String] = {
           return Map[String, String](
             ("IP" -> m.group(1)),
             ("client" -> m.group(2)),
             ("user" -> m.group(3)),
             ("date" -> m.group(4)),
             ("method" -> m.group(5)),
             ("request" -> m.group(6)),
             ("protocol" -> m.group(7)),
             ("respCode" -> m.group(8)),
             ("size" -> m.group(9))
)}
  
}