package com.learn.spark.recommendation

import com.learn.spark.SparkUtils

import org.apache.spark.mllib.recommendation.{ALS, MatrixFactorizationModel, Rating}

import org.apache.spark.sql._

/**
 * @author yaggarwal
 */
object MovieRecommendation extends App{
  
  val sc = SparkUtils.getSparkContext("Spark Recommendation EngineL")
  val sqlContext = SparkUtils.getSparkSqlConext(sc)
  import sqlContext.implicits._  
  
  
  case class Movie(movieId: Int, title: String, genres: Seq[String])
  
  case class User(userId: Int, age: Int, gender: String, occupation: Int, zip: String)
  
  //Parse movie data
  def parseMovie(str: String): Movie = {
    
    val fields = str.split("|")
    Movie(fields(1).toInt, fields(1), Seq(fields(4),fields(5),fields(6),fields(7),fields(8),fields(9),fields(10),fields(11),fields(12),fields(13),fields(14),fields(15),fields(16),fields(17),fields(18),fields(19),fields(20),fields(21),fields(22)))
    
  }
  
  //pasre user data
  def parseUser(str: String): User = {
      val fields = str.split("|")
      User(fields(0).toInt, fields(1).toInt, fields(2), fields(3).toInt, fields(4).toString)
 }
  
  //parse rating data
  def parseRating(str: String): Rating= {
      val fields = str.split("\t")
      Rating(fields(0).toInt, fields(1).toInt, fields(2).trim().toDouble)
}
  
 val ratingText = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/analytics/spark/data-sets/ml-100k/u.data")
 
 val ratingsRDD = ratingText.map(parseRating).cache()
 
 println("Total number of ratings: " + ratingsRDD.count())

 println("Total number of movies rated: " + ratingsRDD.map(_.product).distinct().count())

 println("Total number of users who rated movies: " + ratingsRDD.map(_.user).distinct().count())
 
 
 //Create DF of all three RDDs
 val usersDF = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/analytics/spark/data-sets/ml-100k/u.user").map(parseUser).toDF()
 
   val moviesDF = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/analytics/spark/data-sets/ml-100k/u.item").map(parseMovie).toDF()
 //val moviesDF = movieData.map(parseMovie).toDF()

 
 val ratingsDF = ratingsRDD.toDF()
 
 
 //Register all 3 RDDs as temp tables
   ratingsDF.registerTempTable("ratings")
   moviesDF.registerTempTable("movies")
   usersDF.registerTempTable("users")
 
 usersDF.printSchema()
 moviesDF.printSchema()
 ratingsDF.printSchema()
 
 
 // Get the max, min ratings along with the count of users who have
// rated a movie.
//val results = sqlContext.sql(
//  """select movies.title, movierates.maxr, movierates.minr, movierates.cntu
//    from(SELECT ratings.product, max(ratings.rating) as maxr,
//    min(ratings.rating) as minr,count(distinct user) as cntu
//    FROM ratings group by ratings.product ) movierates
//    join movies on movierates.product=movies.movieId
//    order by movierates.cntu desc""")
//
//// DataFrame show() displays the top 20 rows in  tabular form
//results.show()


// Show the top 10 most-active users and how many times they rated
// a movie
val mostActiveUsersSchemaRDD = sqlContext.sql(
  """SELECT ratings.user, count(*) as ct from ratings
  group by ratings.user order by ct desc limit 10""")

println(mostActiveUsersSchemaRDD.collect().mkString("\n"))

// Find the movies that user 4169 rated higher than 4
val results1 = sqlContext.sql(
    """SELECT ratings.user, ratings.product,
  ratings.rating, movies.title FROM ratings JOIN movies
  ON movies.movieId=ratings.product
  where ratings.user=405 and ratings.rating > 3""")

results1.show()


val selectedMovies = sqlContext.sql("""select * from movies""")
selectedMovies.show()


val splits = ratingsRDD.randomSplit(Array(0.8, 0.2), 0L)

val trainingRatingsRDD = splits(0).cache()
val testRatingsRDD = splits(1).cache()

val numTraining = trainingRatingsRDD.count()
val numTest = testRatingsRDD.count()
println(s"Training: $numTraining, test: $numTest.")

// build a ALS user product matrix model with rank=20, iterations=10
val model = (new ALS().setRank(20).setIterations(10).run(trainingRatingsRDD))



// Get the top 4 movie predictions for user 4169
val topRecsForUser = model.recommendProducts(405, 5)

topRecsForUser.foreach { println }

/* 
Rating(405,279,6.609348971129165)
Rating(405,81,5.699127498091618)
Rating(405,234,5.629608212255651)
Rating(405,8,5.499321416724456)
Rating(405,502,5.41642279417016)
*/

// get movie titles to show with recommendations
val movieTitles=moviesDF.map(array => (array(0), array(1))).collectAsMap()

// print out top recommendations for user 4169 with titles
topRecsForUser.map(rating => (movieTitles.getOrElse(rating.product, "default title"), rating.rating)).foreach(println)

/*
 (default title,6.609348971129165)
(default title,5.699127498091618)
(default title,5.629608212255651)
(8,5.499321416724456)
(default title,5.41642279417016)
 */
  
  
  // get user product pair from testRatings
val testUserProductRDD = testRatingsRDD.map {
  case Rating(user, product, rating) => (user, product)
}

// get predicted ratings to compare to test ratings
val predictionsForTestRDD  = model.predict(testUserProductRDD)

predictionsForTestRDD.take(10).mkString("\n")




// prepare predictions for comparison
val predictionsKeyedByUserProductRDD = predictionsForTestRDD.map{
  case Rating(user, product, rating) => ((user, product), rating)
}

// prepare test for comparison
val testKeyedByUserProductRDD = testRatingsRDD.map{
  case Rating(user, product, rating) => ((user, product), rating)
}

//Join the test with predictions
val testAndPredictionsJoinedRDD = testKeyedByUserProductRDD.
  join(predictionsKeyedByUserProductRDD)

// print the (user, product),( test rating, predicted rating)
testAndPredictionsJoinedRDD.take(3).mkString("\n")




val falsePositives = (
  testAndPredictionsJoinedRDD.filter{
    case ((user, product), (ratingT, ratingP)) => (ratingT <= 1 && ratingP >=4)
  })
falsePositives.take(2)

falsePositives.count()
 
}