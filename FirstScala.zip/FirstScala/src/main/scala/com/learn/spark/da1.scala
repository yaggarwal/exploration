package com.learn.spark

/**
 * @author yaggarwal
 */
object da1 {

  def main(args: Array[String]) {

    //tuple.mapValue function == ?You can modify or do whatever modificaton with the value part
    //out[ut will be key and the modified value
    
    val sc = SparkUtils.getSparkContext("Spark Secondary Sorting in memory")
    /*val a = sc.parallelize(List("dog", "tiger", "lion", "cat", "panther", "eagle"))
    val b = a.map(x => (x.length, x))
    b.mapValues("x" + _ + "x").foreach(print)*/

    //load text file - create base RDD
    // res0: Array[String] = Array("x 2 9 ", "y 2 5 ", "x 1 3 ", "y 1 7 ", "y 3 1 ", "x 3 6 ", "z 1 4 ", "z 2 8 ", "z 3 7  ", "z 4 0 ", "p 2 6 ", "p 4 7 ", "p 1 9 ", "p 6 0 ", p 7 3)
    val textFile = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch1.txt")

    //Create another RDD 0f form (name, (time, value)) pair
    // res1: Array[(String, (String, String))] = Array((x,(2,9)), (y,(2,5)), (x,(1,3)), (y,(1,7)), (y,(3,1)), (x,(3,6)), (z,(1,4)), (z,(2,8)), (z,(3,7)), (z,(4,0)), (p,(2,6)), (p,(4,7)), (p,(1,9)), (p,(6,0)), (p,(7,3)))
    val keyPairData = textFile.map(_.split(" ")).map(r => (r(0), (r(1), r(2))))

    //print the above data
    keyPairData.foreach(print)

    //group the data by key
    // res2: Array[(String, Iterable[(String, String)])] = Array((z,CompactBuffer((1,4), (2,8), (3,7), (4,0))), (p,CompactBuffer((2,6), (4,7), (1,9), (6,0), (7,3))), (x,CompactBuffer((2,9), (1,3), (3,6))), (y,CompactBuffer((2,5), (1,7), (3,1))))
    val groupByKeyData = keyPairData.groupByKey();

    //print the grouped data
    groupByKeyData.foreach(print)

    //res3: Array[(String, Iterable[String])] = Array((z,List(4, 8, 7, 0)), (p,List(6, 7, 9, 0, 3)), (x,List(9, 3, 6)), (y,List(5, 7, 1)))
    val result = groupByKeyData.mapValues(_.map(_._2))

    
    //convert Iterable[String]) to List[String]
    val result1=result.mapValues(_.toList)
    result1.foreach(print)
    
    //now you can sort the values in the list 
    //res9: Array[(String, List[String])] = Array((z,List(0, 4, 7, 8)), (p,List(0, 3, 6, 7, 9)), (x,List(3, 6, 9)), (y,List(1, 5, 7)))
    val result2=result1.mapValues(_.sorted)
    
    result2.foreach(print)
    
    //--------Method 2 --sort by temperature-------------------
    //sort the values by temperature
    
    //res12: Array[(String, Iterable[String])] = Array((z,List((1,4), (2,8), (3,7), (4,0))), (p,List((2,6), (4,7), (1,9), (6,0), (7,3))), (x,List((2,9), (1,3), (3,6))), (y,List((2,5), (1,7), (3,1))))
    val toTuples = groupByKeyData.mapValues(_.map((_.toString())))
    
    //this sorts by temperature
    // res24: Array[(String, List[(String, String)])] = Array((z,List(((1,4)), ((2,8)), ((3,7)), ((4,0)))), (p,List(((1,9)), ((2,6)), ((4,7)), ((6,0)), ((7,3)))), (x,List(((1,3)), ((2,9)), ((3,6)))), (y,List(((1,7)), ((2,5)), ((3,1)))))
   // use mapValues function
    // 1. first convert each Iterable[String]) to List[String]
    // 2. within List -  each string is a tuple - so convert string value to tuple
    // again apply mapValue function to sort by the first key - i.e temperature
    val sortByTemp = toTuples.mapValues (x=>x.toList.map { x => (x.split(",")(0), x.split(",")(1)) }).mapValues(_.sortBy(_._1))

    //res26: Array[(String, List[String])] = Array((z,List(4), 8), 7), 0))), (p,List(9), 6), 7), 0), 3))), (x,List(3), 9), 6))), (y,List(7), 5), 1))))
    val dataSortedByTemp = sortByTemp.mapValues(_.map(_._2))
  }
}