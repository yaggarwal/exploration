package com.learn.spark

import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.types.BooleanType
import org.apache.spark.sql.types.DoubleType
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.DeserializationFeature
/**
 * @author yaggarwal
 * 
 * http://blog.antlypls.com/blog/2016/01/30/processing-json-data-with-sparksql/
 * 
 *{  
   "name":"mission",
   "pandas":[  
      {  
         "id":1,
         "zip":"94110",
         "pt":"giant",
         "happy":true,
         "attributes":[  
            0.4,
            0.5
         ]
      }
   ]
}
 * 
 */
object Pandas extends App{
 
   val sc = SparkUtils.getSparkContext("Spark Simple SQL")
  val sqlContext = SparkUtils.getSparkSqlConext(sc)
  
  /// this is used to implicitly convert an RDD to a DataFrame.
  import sqlContext.implicits._
  
  
  //Method 1 - specify the schema manually and read it
  
  val schema = (new StructType)
  .add("name", StringType)
  .add("pandas", ArrayType(
                            (new StructType)
                            .add("id", LongType)
                            .add("zip", StringType)
                            .add("pt", StringType)
                            .add("happy", BooleanType)
                            .add("attributes", ArrayType(DoubleType))
                          )
      
   )
 
  // similalry can be read orc or parquet files
  val pandaInfo = sqlContext.read.schema(schema).json("/Users/yaggarwal/Documents/Tech-Learning/spark/data/spark-sql-pandas.json")
  //val pandaInfo =  sqlContext.read.json("/Users/yaggarwal/Documents/Tech-Learning/spark/data/spark-sql-pandas.json")
  //pandaInfo.printSchema()
  //pandaInfo.show()
  
  val sadPandas = pandaInfo.filter(pandaInfo("pandas")(0)("happy") !== true)
  //sadPandas.show()
  
  
  
  //Method 2 -  read the json file as RDD and convert that to dataframe
  val pandaRDD = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/spark-sql-pandas.json")
  val pandaInfo1 = sqlContext.read.json(pandaRDD)
  pandaInfo1.printSchema()
  val sadPandas1 = pandaInfo1.filter(pandaInfo1("pandas")(0)("happy") !== true)
  //sadPandas1.show()
  
  //Method 3 - Parse the JSon file and convert it into schema of case classes
  // https://github.com/databricks/learning-spark/blob/master/src/main/scala/com/oreilly/learningsparkexamples/scala/BasicParseJsonWithJackson.scala
  case class RawPanda(id: Long, zip: String, pt: String, happy: Boolean, attributes: Array[Double])
  case class PandaPlace(name: String, pandas: Array[RawPanda])
  
  // Parse it into a specific case class. We use mapPartitions beacuse:
    // (a) ObjectMapper is not serializable so we either create a singleton object encapsulating ObjectMapper
    //     on the driver and have to send data back to the driver to go through the singleton object.
    //     Alternatively we can let each node create its own ObjectMapper but that's expensive in a map
    // (b) To solve for creating an ObjectMapper on each node without being too expensive we create one per
    //     partition with mapPartitions. Solves serialization and object creation performance hit.
    val result = pandaRDD.mapPartitions(records => {
        // mapper object created on each executor node
        val mapper = new ObjectMapper with ScalaObjectMapper
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        mapper.registerModule(DefaultScalaModule)
        // We use flatMap to handle errors
        // by returning an empty list (None) if we encounter an issue and a
        // list with one element if everything is ok (Some(_)).
        records.flatMap(record => {
          try {
            Some(mapper.readValue(record, classOf[PandaPlace]))
          } catch {
            case e: Exception => None
          }
        })
    }, true)
    
    
    println("Printing details...")
     val pandaInfo2 = result.toDF();
   pandaInfo2.printSchema()
   pandaInfo2.show()
   val sadPandas2 = pandaInfo2.filter(pandaInfo2("pandas")(0)("happy") !== true)
    //sadPandas2.show()
    

}