package com.learn.spark.recommendation

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

/**
 * @author yaggarwal
 */
object MovieRecommendationNew {
  
  
    def main(args: Array[String]) {
      val TRAIN_FILENAME = "/Users/yaggarwal/Documents/Tech-Learning/spark/data/ml-100k/ua.base"
      val MOVIES_FILENAME = "/Users/yaggarwal/Documents/Tech-Learning/spark/data/ml-100k/u.item"
      val SPARK_MATSER_URL = "spark://m-yaggarwal.local:7077"
      
      val PRIOR_COUNT = 10
      val PRIOR_CORRELATION = 0
    
      val conf = new SparkConf()
      //conf.setMaster("spark://m-yaggarwal.local:7077")
      conf.setMaster("local")
      conf.setAppName(SPARK_MATSER_URL)
      
      val sc = new SparkContext(conf)
    
      
      // extract (userid, movieid, rating) from ratings data
      val ratings  = sc.textFile(TRAIN_FILENAME)
                      .map { x => x.split("\t")}
                      .map { x => (x(0).toInt, x(1).toInt, x(2).toInt) }
                      
                      
     //get num raters per movie, keyed on movie id
       val numRatersPerMovie = ratings.groupBy(tup => tup._2)
                              .map(grouped => (grouped._1, grouped._2.size))
                                      
       //numRatersPerMovie.foreach(println)
       
       
       // join ratings with num raters on movie id
       //(user, movie, rating, numRaters).
       val ratingsWithSize = ratings.groupBy(tup => tup._2).join(numRatersPerMovie).join(numRatersPerMovie).flatMap(joined => {joined._2._1._1.toList.map(f => (f._1, f._2, f._3, joined._2._2)) })
         
       
       ratingsWithSize.foreach(println)
       
       
       // dummy copy of ratings for self join
       val ratings2 = ratingsWithSize.keyBy(tup => tup._1)
       
       //// join on userid and filter movie pairs such that we don't double-count and exclude self-pairs
       //ratingsWithSize.keyBy(tup => tup._1).join(ratings2).foreach(println)
       val ratingPairs = ratingsWithSize.keyBy(tup => tup._1).join(ratings2).filter(f => f._2._1._2 < f._2._2._2)
       
        //val ratingPairs1 = ratingsWithSize.keyBy(tup => tup._1).join(ratings2).filter(f => f._2._1._2 == f._2._2._2)
    
       //ratingPairs1.take(5).foreach(println)
       ratingPairs.take(5).foreach(println)
       
       
       
       // compute raw inputs to similarity metrics for each movie pair
      val vectorCalcs =
        ratingPairs
        .map(data => {
          val key = (data._2._1._2, data._2._2._2)
          val stats =
            (data._2._1._3 * data._2._2._3, // rating 1 * rating 2
              data._2._1._3,                // rating movie 1
              data._2._2._3,                // rating movie 2
              math.pow(data._2._1._3, 2),   // square of rating movie 1
              math.pow(data._2._2._3, 2),   // square of rating movie 2
              data._2._1._4,                // number of raters movie 1
              data._2._2._4)                // number of raters movie 2
          (key, stats)
        })
        .groupByKey()
        .map(data => {
          val key = data._1
          val vals = data._2
          val size = vals.size
          val dotProduct = vals.map(f => f._1).sum
          val ratingSum = vals.map(f => f._2).sum
          val rating2Sum = vals.map(f => f._3).sum
          val ratingSq = vals.map(f => f._4).sum
          val rating2Sq = vals.map(f => f._5).sum
          val numRaters = vals.map(f => f._6).max
          val numRaters2 = vals.map(f => f._7).max
          (key, (size, dotProduct, ratingSum, rating2Sum, ratingSq, rating2Sq, numRaters, numRaters2))
        })
        
        
        
        // compute similarity metrics for each movie pair
      val similarities =
        vectorCalcs
        .map(fields => {
      
          val key = fields._1
          val (size, dotProduct, ratingSum, rating2Sum, ratingNormSq, rating2NormSq, numRaters, numRaters2) = fields._2
      
          val corr = correlation(size, dotProduct, ratingSum, rating2Sum, ratingNormSq, rating2NormSq)
          val regCorr = regularizedCorrelation(size, dotProduct, ratingSum, rating2Sum,
            ratingNormSq, rating2NormSq, PRIOR_COUNT, PRIOR_CORRELATION)
          val cosSim = cosineSimilarity(dotProduct, scala.math.sqrt(ratingNormSq), scala.math.sqrt(rating2NormSq))
          val jaccard = jaccardSimilarity(size, numRaters, numRaters2)
      
          (key, (corr, regCorr, cosSim, jaccard))
        })
    
}
    
   
    
    def correlation(size : Double, dotProduct : Double, ratingSum : Double,
        rating2Sum : Double, ratingNormSq : Double, rating2NormSq : Double) = {
      
        val numerator = size * dotProduct - ratingSum * rating2Sum
        val denominator = math.sqrt(size * ratingNormSq - ratingSum * ratingSum) * math.sqrt(size * rating2NormSq - rating2Sum * rating2Sum)
      
        numerator / denominator
    }
    
    
    def cosineSimilarity(dotProduct : Double, ratingNorm : Double, rating2Norm : Double) = {
        dotProduct / (ratingNorm * rating2Norm)
    }
    
    def regularizedCorrelation(size : Double, dotProduct : Double, ratingSum : Double,
        rating2Sum : Double, ratingNormSq : Double, rating2NormSq : Double,
        virtualCount : Double, priorCorrelation : Double) = {
      
        val unregularizedCorrelation = correlation(size, dotProduct, ratingSum, rating2Sum, ratingNormSq, rating2NormSq)
        val w = size / (size + virtualCount)
      
        w * unregularizedCorrelation + (1 - w) * priorCorrelation
    }
    
    
    def jaccardSimilarity(usersInCommon : Double, totalUsers1 : Double, totalUsers2 : Double) = {
          val union = totalUsers1 + totalUsers2 - usersInCommon
          usersInCommon / union
     }
}