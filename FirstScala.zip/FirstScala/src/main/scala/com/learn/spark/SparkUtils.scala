package com.learn.spark

import org.apache.spark.SparkConf
import org.apache.spark.streaming.Seconds
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SQLContext
import org.apache.spark.streaming.StreamingContext



/**
 * @author yaggarwal
 */
class SparkUtils private (){
  
}

object SparkUtils {
  
  def apply = new SparkUtils();
  
  def getSparkContext(appName: String) = {
    
    new SparkContext(new SparkConf().setMaster("local").setAppName(appName))
  
  }
  
  def getSparkSqlConext(sc: SparkContext) = {
    
   new SQLContext(sc);
  }
  
  def getStreamingContext() = {
    
    new StreamingContext(new SparkConf(), Seconds(1))

  }
  
}