package com.learn.spark

/**
 * @author yaggarwal
 */
object de4_sparkleftouterjoin extends App{
  
  val sc = SparkUtils.getSparkContext("Implementing left outer join using union")
   
   //users RDD
  // res25: Array[String] = Array(u1 UT, u2 GA, u3 CA, u4 CA, u5 GA)
   val usersRDD = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch4_users.txt")
   usersRDD.foreach { println }
   
   //transactions RDD
  // res26: Array[String] = Array("t1 p3 u1 1 300 ", "t2 p1 u2 1 100 ", "t3 p1 u1 1 100 ", "t4 p2 u2 1 10 ", "t5 p4 u4 1 9 ", "t6 p1 u1 1 100 ", "t7 p4 u1 1 9 ", t8 p4 u5 2 40)
   val transatcionRDD = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch4_transactions.txt")
   transatcionRDD.foreach { println }
   
   //get a tuples of (user_id, location)
   // res27: Array[(String, String)] = Array((u1,UT), (u2,GA), (u3,CA), (u4,CA), (u5,GA))
   val userTuples = usersRDD.map { x => x.split(" ") }.map { x => (x(0), x(1)) }
   userTuples.foreach(println)
   
   //get a tuples of (user_id, product)
   // res28: Array[(String, String)] = Array((u1,p3), (u2,p1), (u1,p1), (u2,p2), (u4,p4), (u1,p1), (u1,p4), (u5,p4))
    val txTuples = transatcionRDD.map { x => x.split(" ") }.map { x => (x(2),  x(1)) }
   txTuples.foreach(println)
   
   // res29: Array[(String, (String, Option[String]))] = Array((u5,(p4,Some(GA))), (u1,(p3,Some(UT))), (u1,(p1,Some(UT))), (u1,(p1,Some(UT))), (u1,(p4,Some(UT))), (u4,(p4,Some(CA))), (u2,(p1,Some(GA))), (u2,(p2,Some(GA))))
   val joinTxProduct = txTuples.leftOuterJoin(userTuples)
   joinTxProduct.foreach(println)
   
   // now fetch only the values part
   // res30: Array[(String, Option[String])] = Array((p4,Some(GA)), (p3,Some(UT)), (p1,Some(UT)), (p1,Some(UT)), (p4,Some(UT)), (p4,Some(CA)), (p1,Some(GA)), (p2,Some(GA)))
   val productLocationPair = joinTxProduct.values
   
   // now aggregate the above result using product as key
   // res31: Array[(String, Iterable[Option[String]])] = Array((p2,CompactBuffer(Some(GA))), (p4,CompactBuffer(Some(GA), Some(UT), Some(CA))), (p1,CompactBuffer(Some(UT), Some(UT), Some(GA))), (p3,CompactBuffer(Some(UT))))
   val groupByProduct = productLocationPair.groupByKey()
   
   //now conver the iteratable values to List.
   // For unique locations convert list to set
   // res32: Array[(String, scala.collection.immutable.Set[Option[String]])] = Array((p2,Set(Some(GA))), (p4,Set(Some(GA), Some(UT), Some(CA))), (p1,Set(Some(UT), Some(GA))), (p3,Set(Some(UT))))
   val uniqueProductLocaion = groupByProduct.mapValues(_.toList.toSet)
  
}