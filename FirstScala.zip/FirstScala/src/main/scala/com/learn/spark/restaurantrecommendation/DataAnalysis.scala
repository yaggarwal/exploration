package com.learn.spark.restaurantrecommendation

import com.learn.spark.SparkUtils

/**
 * @author yaggarwal
 */
object DataAnalysis extends App{
  
  //Count no of restaurants in each city
  
   val sc = SparkUtils.getSparkContext("Spark Restaurant Recommendation EngineL")
   
   val filedata = sc.wholeTextFiles("/Users/yaggarwal/Documents/Tech-Learning/analytics/recommendation-system/data/entree/data")
   
   val files = filedata.map {case(filename, content) => filename}
  
   println("City => restaaurant count")
   files.map { printCityRestaurantCount }
   
   // ##Print the count of restauramts in each city
  
   def printCityRestaurantCount(file: String) = {
     
     var fileContentRDD = sc.textFile(file)
     println(file + "==== > " + fileContentRDD.count)
     
   }
   
  
}