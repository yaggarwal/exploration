package com.learn.spark

import scala.collection.immutable.TreeMap
import org.apache.spark.rdd.RDD
import akka.routing.Broadcast

/**
 * @author yaggarwal
 */
object da3_unique extends App{
  
  /**
   * The same script below will work for the non-unique key data as well, in the case below (as in our cats example).
   * Because key is the weight and is the same in TreeMap , so the below code will work.
   * 
   * But if we have a case like 
   * 
   * url =>  hits
   * 
   * url1 => 3
   * url2 => 4
   * url4 => 5
   * url1 => 2
   * url2 => 7
   * url1 => 3
   * url4 => 10
   * 
   * and we need to find the top 3 urls as per their hits, then the below will not work.
   * We need to aggregate data as per the key first.
   * 
   * RDD.reduceByKey(_ + _)// find total sum of visits for each url. and then you can apply the below logic
   */
   val sc = SparkUtils.getSparkContext("Spark Secondary Sorting in memory")   
   
   case class cats(weight:Int, name:String, id:String)
   
   
   // variable to find the nuumber of top 10
   val n = args(0)
   val bN = sc.broadcast(n.toInt);
   
   //load and create a base RDD from text file
   // parallelize it with 2 partitions
   // org.apache.spark.rdd.RDD[String] = MapPartitionsRDD[1] at textFile at <console>:21
   // Array[String] = Array(12,cat1,cat1, 13,cat2,cat2, 14,cat3,cat3, 15,cat4,cat4, 10,cat5,cat5, 100,cat100,cat100, 200,cat200,cat200, 300,cat300,cat300, 1,cat001,cat001, 67,cat67,cat67, 22,cat22,cat22, 23,cat23,cat23, 1000,cat1000,cat1000, 2000,cat2000,cat2000)
   val catInfo = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/spark/data/da_ch3_unique.txt", 2)
 
   //res33: org.apache.spark.rdd.RDD[Array[String]] = MapPartitionsRDD[2] at map at <console>:25
   // Array[Array[String]] = Array(Array(12, cat1, cat1), Array(13, cat2, cat2), Array(14, cat3, cat3), Array(15, cat4, cat4), Array(10, cat5, cat5), Array(100, cat100, cat100), Array(200, cat200, cat200), Array(300, cat300, cat300), Array(1, cat001, cat001), Array(67, cat67, cat67), Array(22, cat22, cat22), Array(23, cat23, cat23), Array(1000, cat1000, cat1000), Array(2000, cat2000, cat2000))
   val catsRDD = catInfo.map { x => x.split(",") }
   
   // org.apache.spark.rdd.RDD[(Int, (String, String))] = MapPartitionsRDD[3] at map at <console>:27
   // Array[(Int, (String, String))] = Array((12,(cat1,cat1)), (13,(cat2,cat2)), (14,(cat3,cat3)), (15,(cat4,cat4)), (10,(cat5,cat5)), (100,(cat100,cat100)), (200,(cat200,cat200)), (300,(cat300,cat300)), (1,(cat001,cat001)), (67,(cat67,cat67)), (22,(cat22,cat22)), (23,(cat23,cat23)), (1000,(cat1000,cat1000)), (2000,(cat2000,cat2000)))
   val cats1 = catsRDD.map { x => (x(0).toInt, (x(1), x(2))) }
   
   // Now this is where the map  (equivalent to map of map reduce) execution takes place
   // mapPartitions - executed the specified method on each partition. Here we have 2 partitions.
   // It gives input to the method as a Iterator and the method also returns the iterator
   val result = cats1.mapPartitions(takeTopN(_))
   //** Mappper finishes here ***
   
   // Now collect the result of all the partitions - executed above.
   // Note the result is not a RDD - it is a plain scala collection
   val result1=result.collect()
   
   // ***** This is the reducer part***
   //calculated final top N
   val topN = alltopN(result1)
   //*** Reducer finishes here
   
   //Now convert plain scala collection to RDD.
   // RDD can be displayed or can be saved as text file or in any database.
   val finalResult = sc.parallelize(topN.toSeq)
   
   
   finalResult.foreach(print)
   
  
   /*
    * This is the function for mapper
    */
  def takeTopN(itr:Iterator[(Int,(String, String))]) = {
  
    //print("wow..")
     var top10 = new TreeMap[Int, String];
     while(itr.hasNext) {
       
       val cur = itr.next()
      // print(cur._1 + "--" + cur._2)
       top10 = top10.insert(cur._1, cur._2._1)
       if (top10.size > bN.value ) {
         top10 = top10.-(top10.firstKey)
       }
     }
     //top10.foreach(x=>print(x._1, x._2))
     top10.iterator
  
  }
   
    
  
   /*
    * This is the function for reducer
    */
  def alltopN(a:Array[(Int,String)]) = {
    
    var topN = new TreeMap[Int, String]
    a.foreach((x:(Int,String))=> { 
      
        //print("in func" + x._1 + "--" + x._2)
      //print("inserting element...\n")
        topN = topN.insert(x._1, x._2)
        print("size: " + topN.size)
        if (topN.size > bN.value) {
          //print("deleting element..\n")
          topN = topN.-(topN.firstKey)
        }
      }
    )
    //print("----final---")
    topN.foreach((y) => print(y._1 + "==" + y._2))
    topN
  }
   
  
}


