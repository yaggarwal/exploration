package com.learn.spark.streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming._
import org.apache.spark.streaming.flume._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.rdd._
import org.apache.spark.streaming.dstream._
import java.net.InetSocketAddress
import java.io.ObjectOutputStream
import java.io.ObjectOutput
import java.io.ByteArrayOutputStream
import org.apache.hadoop.io._
import org.apache.hadoop.mapreduce._
import org.apache.hadoop.mapred.JobConf
import org.apache.hadoop._

/**
 * @author yaggarwal
 */
object ScalaTransformLogEvents {
  
      def main (args : Array[String]) {
        
        println("Creating Spark Configuration")
        
        
        val conf = new SparkConf()
        
        conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        
        conf.setAppName("Streaming Data Loading Application")
        
        println("Retreiving Streaming Context from Spark Conf")
        val streamCtx = new StreamingContext(conf, Seconds(5))
        
        var addresses = new Array[InetSocketAddress](1);
        addresses(0) = new InetSocketAddress("localhost",4949)
        
        val flumeStream = FlumeUtils.createPollingStream(streamCtx, addresses, StorageLevel.MEMORY_AND_DISK_SER_2, 1000, 1)
        
        
        // printValues(flumeStream,streamCtx)
        
        //Utility class for Transforming Log Data
        val transformLog = new ScalaLogAnalyzer()
        
        //Invoking Flatmap operation to flatening the results and convert them into Key/Value pairs
        val newDstream = flumeStream.flatMap { x => transformLog.transformLogData(new String(x.event.getBody().array())) }
        
        
        /**Start - Transformation Functions */
            executeTransformations(newDstream,streamCtx)
         /**End - Transformation Functions */
            
            
       //Persistance - sabving data to HDFS
            
        streamCtx.start()
        streamCtx.awaitTermination()
        
      }
      
      def executeTransformations(dStream:DStream[(String,String)], streamCtx: StreamingContext) {
        
        //Start - Print all attributes of the Apache Access Log
           printLogValues(dStream,streamCtx)
       //End - Print all attributes of the Apache Access Log
           
           
        // Print onlt the GET requests
           dStream.filter {x => x._1.equals("method") && x._2.contains("GET")}.count().print()
           
       //count the total number of distinct requests forrequested URLs
         val newStream = dStream.filter(x=>x._1.contains("request")).map(x=>(x._2,1))
         newStream.reduceByKey(_+_).print(100)
         
         val transformedRDD = dStream.transform(functionCountRequestType)
         streamCtx.checkpoint("checkpointDir")
         transformedRDD.updateStateByKey(functionTotalCount).print(100)
         
         //Start - Windowing Operation
           executeWindowingOperations(dStream,streamCtx)
         //End - Windowing Operation
        
      }
      
      
      def printLogValues(stream: DStream[(String, String)], streamCtx: StreamingContext) = {
        
        stream.foreachRDD(foreachFunc(_))
      }
      
      def foreachFunc(rdd: RDD[(String, String)]) {
        
        val array = rdd.collect()
        println("---------Start Printing Results----------")
        for(dataMap<-array.array)  {
            print(dataMap._1,"-----",dataMap._2)
        }
        println("---------Finished Printing Results----------")
        
      }
      
      def printValues(stream:DStream[SparkFlumeEvent], streamCtx: StreamingContext){
           
           stream.foreachRDD(foreachFunc)
           //SparkFlumeEvent is the wrapper classes containing all
           //the events captured by the Stream
           def foreachFunc = (rdd: RDD[SparkFlumeEvent]) => {
             val array = rdd.collect()
             println("---------Start Printing Results----------")
             println("Total size of Events= " +array.size)
             for(flumeEvent<-array){
               //This is to get the AvroFlumeEvent from
               //SparkFlumeEvent
               //for printing the Original Data
               val payLoad = flumeEvent.event.getBody()
               //Printing the actual events captured by the Stream
               println(new String(payLoad.array()))
            }
            println("---------Finished Printing Results--------") }
           }
      
      
      val functionCountRequestType = (rdd:RDD[(String, String)]) => {
        
        rdd.filter {f => f._1.contains("methods")}.map(x=>(x._2, 1)).reduceByKey(_+_)
        
      }
      
       val functionTotalCount = (values: Seq[Int], state: Option[Int])=>{
           Option(values.sum + state.sum)
        }
       
       
       def executeWindowingOperations(dStream:DStream[(String, String)],streamCtx: StreamingContext){
           
         //This Provide the Aggregated Count of all response Codes
            
            println("Printing count of Response Code using windowing Operation")
            val wStream = dStream.window(Seconds(40),Seconds(20))
            val respCodeStream = wStream.filter(x=>x._1.contains ("respCode")).map(x=>(x._2,1)) 
            respCodeStream.reduceByKey(_+_).print(100)
            
            //This provide the Aggregated count of all response Codes by using WIndow operation in Reduce method
            println("Printing count of Response Code using reducebyKeyAndWindow Operation")
            val respCodeStream_1 = dStream.filter(x=>x._1.contains("respCode")).map(x=>(x._2,1))
            respCodeStream_1.reduceByKeyAndWindow((x:Int,y:Int)=>x+y,Seconds(40),Seconds(20)).print(100)
            
            //This will apply and print groupByKeyAndWindow in theSliding Window
            println("Applying and Printing groupByKeyAndWindow ina Sliding Window")
            val respCodeStream_2 = dStream.filter(x=>x._1.contains("respCode")).map(x=>(x._2,1))
            respCodeStream_2.groupByKeyAndWindow(Seconds(40),Seconds(20)).print(100)
      }
       
       
        def persistsDstreams(dStream:DStream[(String, String)],streamCtx: StreamingContext) = {
           //Writing Data as Text Files on Local File system.
           //This method takes 2 arguments: -
           //1."prefix" of file, which would be appended with Time
           //(in milliseconds) by Spark API's
           //2."suffix" of the file
           //The final format will be
           //"<prefix><Milliseconds><suffix>"
           dStream.saveAsTextFiles("/home/ec2-user/softwares/spark-1.3.0-bin-hadoop2.4/outputDir/data-", "")
           
           //Creating an Object of Hadoop Config with default Values
           val hConf = new JobConf(new org.apache.hadoop.conf.Configuration())
           
           
           //Defining the TextOutputFormat using old API's
           //available with =<0.20
           val oldClassOutput = classOf[org.apache.hadoop.mapred.TextOutputFormat[Text,Text]]
           
           
           //Invoking Output operation to save data in HDFS using
           //old API's
           //This method accepts following Parameters: -
           //1."prefix" of file, which would be appended with Time
           //(in milliseconds) by Spark API's
           //2."suffix" of the file
           //3.Key - Class which can work with the Key
           //4.Value - Class which can work with the Key
           //5.OutputFormat - Class needed for writing the Output
           //in a specific Format
           //6.HadoopConfig - Object of Hadoop Config
           dStream.saveAsHadoopFiles("hdfs://localhost:9000/spark/streaming/oldApi/data-", "", classOf[Text],classOf[Text], oldClassOutput ,hConf )
 
           
           //Defining the TextOutputFormat using new API's available with >0.20
           val newTextOutputFormat = classOf[org.apache.hadoop.mapreduce.lib.output.TextOutputFormat[Text, Text]]
 
           
           //Invoking Output operation to save data in HDFS usingnew API's
 
            //This method accepts same set of parameters as "saveAsHadoopFiles"
          dStream.saveAsNewAPIHadoopFiles("hdfs://localhost:9000/spark/streaming/newApi/data-", "", classOf[Text], classOf[Text],newTextOutputFormat ,hConf )
          
          //Defining saveAsObject for saving data in form of
          //Hadoop Sequence Files
          dStream.saveAsObjectFiles("hdfs://localhost:9000/spark/streaming/sequenceFiles/data-")
          
          //Using forEachRDD for printing the data for each Partition
          dStream.foreachRDD(
               rdd => rdd.foreachPartition(
                 data=> data.foreach(
                     //Printing the Values which can be replaced by
                     //custom code
                     //for storing data in any other external
                     //System.
                     tup => System.out.println("Key = "+tup._1+", Value = "+tup._2)
                   )
          ) )
  
}
}
       
       
       
      
       