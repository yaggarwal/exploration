package com.learn.spark.KMeans

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.mllib.linalg._
import org.apache.spark.mllib.clustering._
import org.apache.spark.rdd._

/**
 * @author yaggarwal
 */
object RunKMeans {
  
  def main(args:Array[String]) {
    
      val sc = new SparkContext(new SparkConf().setMaster("local").setAppName("K-means"))
      val rawData = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/analytics/spark/data-sets/kddcup.data_10_percent")
     
      
     // clusteringTake0(rawData)
      
  }
  
  def clusteringTake0(rawData: RDD[String]): Unit = {

    rawData.map(_.split(',').last).countByValue().toSeq.sortBy(_._2).reverse.foreach(println)

     /*
       * K-means works with numerical data only
       * so we remove first 1-3 index columns and the last one as the label
       */
    val labelsAndData = rawData.map { line =>
      val buffer = line.split(',').toBuffer
      buffer.remove(1, 3)
      val label = buffer.remove(buffer.length - 1)
      val vector = Vectors.dense(buffer.map(_.toDouble).toArray)
      (label, vector)
    }

    val data = labelsAndData.values.cache()

    val kmeans = new KMeans()
    val model = kmeans.run(data)

    model.clusterCenters.foreach(println)

    val clusterLabelCount = labelsAndData.map { case (label, datum) =>
      val cluster = model.predict(datum)
      (cluster, label)
    }.countByValue()

    clusterLabelCount.toSeq.sorted.foreach { case ((cluster, label), count) =>
      println(f"$cluster%1s$label%18s$count%8s")
    }

    data.unpersist()
  }
  
  
  def distance(a: Vector, b: Vector) = math.sqrt(a.toArray.zip(b.toArray).map(p => p._1 - p._2).map(d => d * d).sum)

  def distToCentroid(datum: Vector, model: KMeansModel) = {
      val cluster = model.predict(datum)
      val centroid = model.clusterCenters(cluster)
      distance(centroid, datum)
  }

  def clusteringScore(data: RDD[Vector], k: Int): Double = {
      val kmeans = new KMeans()
      kmeans.setK(k)
      val model = kmeans.run(data)
      data.map(datum => distToCentroid(datum, model)).mean()
  }

  def clusteringScore2(data: RDD[Vector], k: Int): Double = {
      val kmeans = new KMeans()
      kmeans.setK(k)
      kmeans.setRuns(10)
      kmeans.setEpsilon(1.0e-6)
      val model = kmeans.run(data)
      data.map(datum => distToCentroid(datum, model)).mean()
  }

  def clusteringTake1(rawData: RDD[String]): Unit = {

      val data = rawData.map { line =>
        val buffer = line.split(',').toBuffer
        buffer.remove(1, 3)
        buffer.remove(buffer.length - 1)
        Vectors.dense(buffer.map(_.toDouble).toArray)
      }.cache()
  
      (5 to 30 by 5).map(k => (k, clusteringScore(data, k))).
        foreach(println)
  
      (30 to 100 by 10).par.map(k => (k, clusteringScore2(data, k))).
        toList.foreach(println)
  
      data.unpersist()

  }
  
  
}
  
