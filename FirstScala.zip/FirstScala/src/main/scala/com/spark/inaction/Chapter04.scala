package com.spark.inaction

/**
 * @author yaggarwal
 */
object Chapter04 {
  
  
  
  /*  PARTITIONING
   *  ============
   *  
   *  Partitioning of RDDs is performed by Partitioner objects that assign a partition index to each
      RDD element. 
      Two implementations are provided by Spark: HashPartitioner and
      RangePartitioner. 
      Only Pair RDDs also accept custom partitioners. 
      
      HashParitioner
       - HashPartitioner is the default partitioner in Spark. It calculates a partition index based on an
         element's Java hash code (or a key's hash code in pair RDDs), according to this simple
          formula partitionIndex = hashCode % numberOfPartitions.  
       - The default number of data partitions when using HashPartitioner is determined by the
          Spark configuration parameter spark.default.parallelism. If that parameter isn't specified by the user, it will be set to the number of cores in the cluster. 
   *  
   * RangePartitioner -  Not used much
   * 
   */
  
}