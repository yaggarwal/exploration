package com.nextag.aggregators

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.broadcast.Broadcast


/**
 * @author yaggarwal
 * References:  https://github.com/databricks/spark-csv
 * 
 * //Dataframe APR - https://jaceklaskowski.gitbooks.io/mastering-apache-spark/content/spark-sql-dataframe.html
 * 
 * https://dzone.com/articles/spark-write-csv-file
 * 
 * Tutorials:  http://www.sparktutorials.net/tutorials
 * 
 * http://stackoverflow.com/questions/31615657/how-to-add-a-new-struct-column-to-a-dataframe
 */
object ClickSaleAggregator {
  
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  
  case class Click(when:java.sql.Timestamp, c_sellerId:Long, cpc:Double, c_publisher_id:Int, c_clickId:Long, 
                  ip:String, visitId:String, visitorId:String, productId:Long, fromChannelId:Int, who:String)
  
  case class Sale(saleTime:java.sql.Timestamp, clickTime:java.sql.Timestamp, s_sellerId:Long, revenue:Double, 
                  s_publisher_id:Int, s_clickId:Long, saleAmount:Double, saleAmountEstimated:Double, revShare:Double, saleTrackId:Long)
  
  case class AggregatedResult(c_clickId:Long, saleTrackId:Long, num_clicks:Int, num_sales:Int, revenue:Double, 
                              revShare:Double, saleAmount:Double, saleAmountEstimated:Double, click_time:java.sql.Timestamp, 
                              sellerId:Long, cpc:Double, publisherId:Int, ip:String,visitId:String, visitorId:String, productId:Long, 
                              fromChannelId:Int, who:String, pub_group_id:Int, pub_group_name:String, publisher_name:String, traffic_type:String
                              )
  
  var bpublishIdNameMap:Broadcast[scala.collection.Map[Long,String]] = null
  var bpublishIdGroupIdMap:Broadcast[scala.collection.Map[Long,Int]] = null
  var bpublishIdGroupNameMap:Broadcast[scala.collection.Map[Long,String]] = null
 // var bpublishIdTrafficTypeIdMap:Broadcast[scala.collection.Map[Long,Int]] = null
  var bpublishIdTrafficTypeMap:Broadcast[scala.collection.Map[Long,String]] = null
 
    
  def main(args: Array[String]) {
    
     //getClickSaleData()
     usingSimpleJoin
  }
  
  def usingSimpleJoin {
    
     val conf =   new SparkConf().setAppName("Simple Join").setMaster("local")
    
    val sc = new SparkContext(conf)
     
     val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    import sqlContext.implicits._
    
     val rawClicks = sc.textFile("/Users/yaggarwal/Desktop/clicks_01062016.csv")
    
    val rawSale = sc.textFile("/Users/yaggarwal/Desktop/sales_0616.csv")
    
    val clickObjs = rawClicks.map {parseClickNoSQL}
    
    val saleObjs = rawSale.map {parseSaleNoSQL}
   
    
    //broadcast the necessary variables
    
    val rawClickTraffictype = sc.textFile("/Users/yaggarwal/Documents/Tech-Learning/hadoop/data/click_sale/publisher_taffic_type2.csv")
    val clickTrafficTypeArray = rawClickTraffictype.map { _.split(",")}
    clickTrafficTypeArray.cache()
    
    val publishIdNameMap = clickTrafficTypeArray.map ( x => {println(x(0).toString());(x(0).toLong, if (x(1) == "null")  "N.A" else x(1)) }).collectAsMap()
    val publishIdGroupIdMap = clickTrafficTypeArray.map ( x => {println(x(0).toString());(x(0).toLong, if (x(2) == "null")  0 else x(2).toInt) } ).collectAsMap()
    val publishIdGroupNameMap = clickTrafficTypeArray.map ( x => (x(0).toLong, if (x(3) == "null") "N.A" else x(3)) ).collectAsMap()
    //val publishIdTrafficTypeIdMap = clickTrafficTypeArray.map ( x => (x(0).toLong, if (x(4) == "null") 0 else x(4).toInt) ).collectAsMap()
    val publishIdTrafficTypeMap = clickTrafficTypeArray.map ( x => (x(0).toLong, if (x(4) == "null") "N.A" else x(4)) ).collectAsMap()
    
    
     bpublishIdNameMap = sc.broadcast(publishIdNameMap)
     bpublishIdGroupIdMap = sc.broadcast(publishIdGroupIdMap)
     bpublishIdGroupNameMap = sc.broadcast(publishIdGroupNameMap)
     //bpublishIdTrafficTypeIdMap = sc.broadcast(publishIdTrafficTypeIdMap)
     bpublishIdTrafficTypeMap = sc.broadcast(publishIdTrafficTypeMap)
    
    
    val clickSaleJoin = clickObjs.leftOuterJoin(saleObjs)
    
    val aggreagratedResultRDD = clickSaleJoin.combineByKey(customCombiner(_), customMergeValue, mergeCustomCombiners)
    
    aggreagratedResultRDD.filter(_._2.num_sales == 4).take(1000).foreach(println)
    
    aggreagratedResultRDD.values.toDF().repartition(1)
           .write
          .format("com.databricks.spark.csv")
          .option("header", "true")
         .save("/Users/yaggarwal/Documents/Tech-Learning/joinsimple")
    
  }
  
  
  
  case class AggregatedResult1(c_clickId:Long, saleTrackId:Long, num_clicks:Int, num_sales:Int, revenue:Double, 
                              revShare:Double, saleAmount:Double, saleAmountEstimated:Double, 
                              click_time:java.sql.Timestamp, 
                              sellerId:Long,
                              cpc:Double, 
                              publisherId:Int,
                              ip:String,
                              visitId:String, 
                              visitorId:String, 
                              productId:Long, 
                              fromChannelId:Int, 
                              who:String,
                              pub_group_id:Int, 
                              pub_group_name:String, 
                              traffic_type_id:Int, 
                              traffic_type:String)
                              
  def customCombiner(row:(Click, Option[Sale])) = {    
    
    row match {
      case (c:Click, Some(s:Sale)) => {
                                      AggregatedResult(
                                      c.c_clickId,s.saleTrackId,1,1,s.revenue,s.revShare,s.saleAmount,s.saleAmountEstimated, 
                                      c.when, c.c_sellerId, c.cpc, c.c_publisher_id, c.ip, c.visitId, c.visitorId, c.productId, c.fromChannelId, c.who,
                                      bpublishIdGroupIdMap.value.getOrElse(c.c_publisher_id, -1),
                                      bpublishIdGroupNameMap.value.getOrElse(c.c_publisher_id, "N.A"),
                                      bpublishIdNameMap.value.getOrElse(c.c_publisher_id, "N.A"),
                                      bpublishIdTrafficTypeMap.value.getOrElse(c.c_publisher_id, "N.A")
                                      )
                                      }
      
      case(c:Click, None) => {
                               AggregatedResult(
                                c.c_clickId,0,1,0,0.toDouble,0.toDouble,0.toDouble,0.toDouble,
                                c.when, c.c_sellerId, c.cpc, c.c_publisher_id, c.ip, c.visitId, c.visitorId, c.productId, c.fromChannelId, c.who,
                                bpublishIdGroupIdMap.value.getOrElse(c.c_publisher_id, -1),
                                bpublishIdGroupNameMap.value.getOrElse(c.c_publisher_id, "N.A"),
                                bpublishIdNameMap.value.getOrElse(c.c_publisher_id, "N.A"),
                                bpublishIdTrafficTypeMap.value.getOrElse(c.c_publisher_id, "N.A") 
                               )
                             }
    }
    
  }
  
  def customMergeValue(ar:AggregatedResult, row:(Click, Option[Sale])) = {
    
    row match {
      case (c:Click, Some(s:Sale)) => {
                                        AggregatedResult(
                                            c.c_clickId,s.saleTrackId,ar.num_clicks, ar.num_sales + 1, ar.revenue + s.revenue, 
                                            ar.revShare + s.revShare, ar.saleAmount + s.saleAmount, 
                                            ar.saleAmountEstimated + s.saleAmountEstimated,
                                            c.when, c.c_sellerId, c.cpc, c.c_publisher_id, c.ip, c.visitId, c.visitorId, c.productId, c.fromChannelId, c.who,
                                            ar.pub_group_id, ar.pub_group_name,
                                            ar.publisher_name, ar.traffic_type
                                        )}
      //case(c:Click, None) => {AggregatedResult(c.c_clickId,0,1,0,0,0,0,0)}
    }
    
  }
  
  
  def mergeCustomCombiners(ar1:AggregatedResult, ar2:AggregatedResult) = {
    
    AggregatedResult(ar1.c_clickId, ar1.saleTrackId, ar1.num_clicks, ar1.num_sales +  ar2.num_sales, ar1.revenue + ar2.revenue, 
                     ar1.revShare + ar2.revShare, ar1.saleAmount + ar2.saleAmount, ar1.saleAmountEstimated + ar2.saleAmountEstimated,
                     ar1.click_time, ar1.sellerId, ar1.cpc, ar1.publisherId, ar1.ip, ar1.visitId, ar1.visitorId, ar1.productId, ar1.fromChannelId, ar1.who,
                     ar1.pub_group_id, ar1.pub_group_name,
                     ar1.publisher_name, ar1.traffic_type
                    )
                    
  }
  
  def parseClickNoSQL(click: String) = {
    
    val clickArr = click.split(",")
    val when_ = new java.sql.Timestamp(format.parse(clickArr(0)).getTime)
    val sellerId:Long = clickArr(1).toLong
    var cpc:Double = 0.0
    if (clickArr(2) == "NULL") 
        cpc = 0.0
    else
         cpc = clickArr(2).toDouble
    
    val publisherId:Int = clickArr(3).toInt
    val clickId:Long = clickArr(4).toLong
    
    //(clickId, Click(when_, sellerId, cpc, publisherId, clickId))
    
    val ip:String = clickArr(5)
    val visit_id:String = clickArr(6)
    val visitor_id:String = clickArr(7)
    val product_id:Long = clickArr(8).toLong
    val from_channel_id:Int = clickArr(9).toInt
    val who:String = clickArr(10)
    
    (clickId, Click(when_, sellerId, cpc, publisherId, clickId, ip, visit_id, visitor_id, product_id, from_channel_id, who))
  }
  
  def parseClick(click: String) = {
    
    val clickArr = click.split(",")
    val when_ = new java.sql.Timestamp(format.parse(clickArr(0)).getTime)
    val sellerId:Long = clickArr(1).toLong
    var cpc:Double = 0.0
    if (clickArr(2) == "NULL") 
        cpc = 0.0
    else
         cpc = clickArr(2).toDouble
    
    val publisherId:Int = clickArr(3).toInt
    val clickId:Long = clickArr(4).toLong
    
    //(clickId, Click(when_, sellerId, cpc, publisherId, clickId))
    
    val ip:String = clickArr(5)
    val visit_id:String = clickArr(6)
    val visitor_id:String = clickArr(7)
    val product_id:Long = clickArr(8).toLong
    val from_channel_id:Int = clickArr(9).toInt
    val who:String = clickArr(10)
    
    Click(when_, sellerId, cpc, publisherId, clickId, ip, visit_id, visitor_id, product_id, from_channel_id, who)
  }
  
  
  def parseSaleNoSQL(sale: String) = {
    
    val saleArr = sale.split(",")
    val saleTime = new java.sql.Timestamp(format.parse(saleArr(0)).getTime)
    val clickTime = new java.sql.Timestamp(format.parse(saleArr(1)).getTime)
    val sellerId = saleArr(2).toLong
    var revenue:Double=0.0
    
    if (saleArr(3) == "NULL") 
        revenue = 0.0
    else
         revenue = saleArr(3).toDouble
    
    val publisherId = saleArr(4).toInt
    val clickId = saleArr(5).toLong
    
    var sale_amount:Double = 0.0
      
    if (saleArr(6) == "NULL") 
        sale_amount = 0.0
    else
         sale_amount = saleArr(6).toDouble
         
    var sale_amount_estimated:Double =0.0
      
    if (saleArr(7) == "NULL") 
        sale_amount_estimated = 0.0
    else
         sale_amount_estimated = saleArr(7).toDouble
         
    var revshare:Double = 0.0
    
    
    if (saleArr(8) == "NULL") 
        revshare = 0.0
    else
         revshare = saleArr(8).toDouble
         
    val saleTrackId:Long = saleArr(9).toLong
    
    //(clickId, Sale(saleTime, clickTime, sellerId, revenue, publisherId, clickId))
    (clickId, Sale(saleTime, clickTime, sellerId, revenue, publisherId, clickId, sale_amount, sale_amount_estimated, revshare, saleTrackId))
    
  }
  
  def parseSale(sale: String) = {
    
    val saleArr = sale.split(",")
    val saleTime = new java.sql.Timestamp(format.parse(saleArr(0)).getTime)
    val clickTime = new java.sql.Timestamp(format.parse(saleArr(1)).getTime)
    val sellerId = saleArr(2).toLong
    var revenue:Double=0.0
    
    if (saleArr(3) == "NULL") 
        revenue = 0.0
    else
         revenue = saleArr(3).toDouble
    
    val publisherId = saleArr(4).toInt
    val clickId = saleArr(5).toLong
    
    var sale_amount:Double = 0.0
      
    if (saleArr(6) == "NULL") 
        sale_amount = 0.0
    else
         sale_amount = saleArr(6).toDouble
         
    var sale_amount_estimated:Double =0.0
      
    if (saleArr(7) == "NULL") 
        sale_amount_estimated = 0.0
    else
         sale_amount_estimated = saleArr(7).toDouble
         
    var revshare:Double = 0.0
    
    
    if (saleArr(8) == "NULL") 
        revshare = 0.0
    else
         revshare = saleArr(8).toDouble
         
    val saleTrackId:Long = saleArr(9).toLong
    
    //(clickId, Sale(saleTime, clickTime, sellerId, revenue, publisherId, clickId))
    Sale(saleTime, clickTime, sellerId, revenue, publisherId, clickId, sale_amount, sale_amount_estimated, revshare, saleTrackId)
    
  }
  
  
  def getClickSaleData() {
    
    val conf =   new SparkConf().setAppName("Simple Join").setMaster("local")
    
    val sc = new SparkContext(conf)
    
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    import sqlContext.implicits._
    
    
    val rawClicks = sc.textFile("/Users/yaggarwal/Desktop/clicks_01062016.csv")
    
    val rawSale = sc.textFile("/Users/yaggarwal/Desktop/sales_0616.csv")
    
    val clickObjs = rawClicks.map {parseClick}
    
    val saleObjs = rawSale.map {parseSale}
    
    val clickDF = clickObjs.toDF()
    val salesDF = saleObjs.toDF()
    

   // clickDF.printSchema()
    //salesDF.printSchema()
    
    val joinDF = clickDF.as("c").join(salesDF.as("s"), $"c.c_clickId" === $"s.s_clickId", "left_outer")
    
     val trafficTypedf = sqlContext.read
              .format("com.databricks.spark.csv")
              .option("header", "true") // Use first line of all files as header
              .option("inferSchema", "true") // Automatically infer data types
              .option("delimiter", "~")
              .load("/Users/yaggarwal/Documents/Tech-Learning/hadoop/data/click_sale/publisher_taffic_type.csv")
          
   // trafficTypedf.printSchema()
    
    val resultDF = joinDF.as("j").join(trafficTypedf.as("t"), $"j.c_publisher_id" === $"t.PUBLISHER_ID", "left_outer")
    
    resultDF.registerTempTable("ClickSale")
    
    val cleanResultDF = sqlContext.sql("Select when, c_sellerId, cpc, c_publisher_id, c_clickId, nvl(saleTime, '0000-00-00 00:00:00'), nvl(clickTime, '0000-00-00 00:00:00'), nvl(revenue, 0.0), CLICK_TRAFFIC_TYPE, ip, visitId, visitorId, productId, fromChannelId, who, nvl(saleAmount, 0.0), nvl(saleAmountEstimated, 0.0), nvl(revShare, 0.0), nvl(saleTrackId, 0) from ClickSale")
    
   
    //cleanResultDF.take(100).foreach { println }
    //clickDF.registerTempTable("Click")
    //salesDF.registerTempTable("Sales")
    
    
    //val joinDF = sqlContext.sql("select *  from Click c LEFT OUTER JOIN Sales s ON c.clickId = s.clickId")
    //joinDF.printSchema()
    
    val cleanResultRDD = cleanResultDF.rdd
    cleanResultRDD.take(5).foreach { println}
    
    cleanResultDF.groupBy("c_clickId").count().foreach {println }
   
//    cleanResultDF.repartition(1)
//           .write
//          .format("com.databricks.spark.csv")
//          .option("header", "true")
//          .save("/Users/yaggarwal/Documents/Tech-Learning/joinnew")
//          
          
    //create publisher traffic type dataframe
    
    
  }
  
}

